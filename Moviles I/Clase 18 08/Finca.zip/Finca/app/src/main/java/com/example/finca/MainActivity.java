package com.example.finca;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    EditText cantidad;
    TextView neto, total;
    RadioButton eco, normal, pro;
    Button calcular;
    Switch transporte;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Esconder titulo por defecto
        getSupportActionBar().hide();
        //asociar objetos Java con objetos xml
        cantidad = findViewById(R.id.cantidad);
        neto = findViewById(R.id.neto);
        total = findViewById(R.id.total);
        eco = findViewById(R.id.eco);
        normal = findViewById(R.id.normal);
        pro = findViewById(R.id.pro);
        calcular = findViewById(R.id.calcular);
        transporte = findViewById(R.id.transporte);
    }

    public void Calcular(View view) {
        String cant;
        cant = cantidad.getText().toString();
        if (cant.isEmpty()) {
            Toast.makeText(this, "Digite cantidad de personas", Toast.LENGTH_LONG).show();
            cantidad.requestFocus();
        } else {
            int cantPer, categoria, sobrecosto=0;
            int transport, fincaneta, fincatotal;
            cantPer = Integer.parseInt(cant);
            if (eco.isChecked()) {
                categoria = 600000;
                eco.setText("Económico $600.000");
            } else {
                if (normal.isChecked()) {
                    categoria = 1000000;
                    normal.setText("Normal 1.000.000");
                } else {
                    categoria = 1500000;
                    pro.setText("Premium $1.500.000");
                }
            }
            if (transporte.isChecked()) {
                transport = (30000 * cantPer);
                transporte.setText("Transporte 30000 c/u");
            } else {
                transporte.setText("Transporte");
                transport = 0;
            }
            if (cantPer > 30) {
                sobrecosto = categoria * 10/100;
            }
            fincaneta = categoria / cantPer;
            fincatotal = fincaneta + sobrecosto / cantPer + (transport / cantPer);
            neto.setText(String.valueOf(fincaneta + " Por persona"));
            total.setText(String.valueOf(fincatotal + " Por persona"));
        }
    }
}


